package com.mrcrayfish.guns.object;

/**
 * Used to display the correct properties in the tooltip in case the server overrides it
 *
 * Author: MrCrayfish
 */
public class ServerGun
{
    public float damage;
    public int maxAmmo;
}
