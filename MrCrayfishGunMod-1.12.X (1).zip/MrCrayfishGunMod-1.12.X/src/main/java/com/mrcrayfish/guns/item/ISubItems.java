package com.mrcrayfish.guns.item;

import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;

/**
 * Author: MrCrayfish
 */
public interface ISubItems
{
    NonNullList<ResourceLocation> getModels();
}
